function addManualEntry(userType = "student") {
  const subject = document.getElementById("subject").value;
  const time = document.getElementById("time").value;
  if (!subject || !time) return alert("Fill both fields");

  const li = document.createElement("li");
  li.textContent = `${time} - ${subject}`;
  document.getElementById("manualList").appendChild(li);

  const key = userType === "employee" ? "employeeSchedule" : "manualSchedule";
  const current = JSON.parse(localStorage.getItem(key)) || [];
  current.push({ activity: subject, time });
  localStorage.setItem(key, JSON.stringify(current));

  scheduleReminder(subject, time);
  document.getElementById("subject").value = "";
  document.getElementById("time").value = "";
}

function scheduleReminder(subject, timeStr) {
  const [hour, minute] = timeStr.split(":").map(Number);
  const now = new Date();
  const scheduleTime = new Date();
  scheduleTime.setHours(hour, minute, 0, 0);
  let delay = scheduleTime - now;
  if (delay < 0) return;

  setTimeout(() => {
    notifyUser(`${timeStr} - ${subject}`);
  }, delay);
}

function notifyUser(msg) {
  if (Notification.permission === "granted") {
    new Notification("Set Schedule Reminder", {
      body: msg,
      icon: "https://img.icons8.com/color/48/todo-list.png"
    });
  } else if (Notification.permission !== "denied") {
    Notification.requestPermission().then(permission => {
      if (permission === "granted") {
        new Notification("Set Schedule Reminder", {
          body: msg
        });
      }
    });
  }
  alert(msg);
  const beep = new Audio("https://www.soundjay.com/buttons/sounds/beep-07.mp3");
  beep.play();
}

// CLOCK
setInterval(() => {
  const now = new Date();
  const time = now.toLocaleTimeString();
  const clock = document.getElementById("clock");
  if (clock) clock.textContent = `⏰ Current Time: ${time}`;
}, 1000);
